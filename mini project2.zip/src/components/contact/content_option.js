const contactConfig = {
    description:
    'lorem  ipsum dolor sit ametlorem  ipsum dolor sit ametlorem  ipsum dolor sit ametlorem  ipsum dolor sit ametlorem  ipsum dolor sit ametlorem  ipsum dolor sit ametlorem  ipsum dolor sit amet'
};

export{
    contactConfig
};