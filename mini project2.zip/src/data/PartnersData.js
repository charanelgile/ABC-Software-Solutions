export const PartnersData1 = [
  {
    partnerLogo: require("../images/partners/deped.png"),
    partnerHeight: 70,
  },
  {
    partnerLogo: require("../images/partners/accenture.png"),
    partnerHeight: 55,
  },
  {
    partnerLogo: require("../images/partners/bpi.png"),
    partnerHeight: 55,
  },
  {
    partnerLogo: require("../images/partners/coca-cola.png"),
    partnerHeight: 45,
  },
  {
    partnerLogo: require("../images/partners/cclex.png"),
    partnerHeight: 40,
  },
];

export const PartnersData2 = [
  {
    partnerLogo: require("../images/partners/globe.png"),
    partnerHeight: 45,
  },
  {
    partnerLogo: require("../images/partners/ayala-land.png"),
    partnerHeight: 45,
  },
  {
    partnerLogo: require("../images/partners/grab.png"),
    partnerHeight: 35,
  },
  {
    partnerLogo: require("../images/partners/philtranco.png"),
    partnerHeight: 35,
  },
  {
    partnerLogo: require("../images/partners/pagcor.png"),
    partnerHeight: 55,
  },
];
