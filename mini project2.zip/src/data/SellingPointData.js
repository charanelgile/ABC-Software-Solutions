export const SellingPointDataA = [
  {
    title: "25+ years",
    text: "of experience at the forefront of the tech industry",
  },
  {
    title: "700+",
    text: "long-term partner businesses nationwide",
  },
  {
    title: "300+",
    text: "projects developed, with over 200 still under our care",
  },
];

export const SellingPointDataB = [
  {
    title: "5-Step",
    text: "comprehensive software solution for business growth",
  },
  {
    title: "100+",
    text: "certified and professional developers and designers",
  },
  {
    title: "24/7",
    text: "active priority support hotline",
  },
];
