export const LifeAtABCData = [
  {
    employeeImage: `url("https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8ZW1wbG95ZWUlMjB3b3JraW5nJTIwcmVtb3RlfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60")`,
    employeeName: "Richard Alvarez",
    employeeRole: "Backend Developer - NodeJS",
    employeeStory: `I was an undergraduate and most of the things I knew in coding when I started
      was just from constant reading and watching tons of tutorial videos in YouTube. But they were
      the only employer who actually gave me a chance despite not having a college diploma...`,
    layout: "row-reverse",
    align: "right",
  },
  {
    employeeImage: `url("https://images.unsplash.com/photo-1524508762098-fd966ffb6ef9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NjB8fGVtcGxveWVlJTIwd29ya2luZyUyMHJlbW90ZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60")`,
    employeeName: "Faith Antazo",
    employeeRole: "HR Supervisor - Employee Relations",
    employeeStory: `What I really love about ABC Software Solutions is that they actually instill
      this work-life balance mindset to all their employees across every department. This way, the
      modern movement of respecting employees time effortlessly becomes a culture...`,
    layout: "row",
    align: "left",
  },
  {
    employeeImage: `url("https://images.unsplash.com/photo-1529421308418-eab98863cee4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NjV8fGVtcGxveWVlJTIwd29ya2luZyUyMHJlbW90ZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60")`,
    employeeName: "Marky Sarmiento",
    employeeRole: "Financial Manager - Research and Development",
    employeeStory: `Even I cannot believe that I'm saying this now. Here at ABC Software Solutions,
      we never worry about our career tracks because our founders live by a code - 'Promote the ones we have
      before hiring someone from the outside.'...`,
    layout: "row-reverse",
    align: "right",
  },
];
